import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp( MyHomePage());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);


  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage>{
  String displayText = "";
  double val = 0;
  final db = FirebaseDatabase.instance.ref().limitToLast(1);

  @override
  void initState(){
    super.initState();
    _actL();
  }

  void _actL(){
    List tl = [];
    db.onValue.listen((event) {
      print(event.snapshot.value);
      if (tl.length > 10){
        tl.remove(tl[0]);
      }
      Map<Object?, dynamic>.from(event.snapshot.value as dynamic).forEach((key, value) => tl.add(value));
          setState(() {
        displayText = tl[tl.length-1];
        print(tl);
        val = double.parse(displayText);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
          appBar: AppBar(
            title: const Text("Ergasia"),
          ),
            body: Center(
                child: Container(
                    child: SfRadialGauge(
                        axes: <RadialAxis>[
                          RadialAxis(minimum: 0, maximum: 366,
                              ranges: <GaugeRange>[
                                GaugeRange(startValue: 0, endValue: 100, color:Colors.green),
                                GaugeRange(startValue: 100,endValue: 290,color: Colors.orange),
                                GaugeRange(startValue: 290,endValue: 366,color: Colors.red)],
                              pointers: <GaugePointer>[
                                NeedlePointer(value:  val)],
                              annotations: <GaugeAnnotation>[
                                GaugeAnnotation(widget: Container(child:
                                Text(displayText,style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold))),
                                    angle: 90, positionFactor: 0.5
                                )]
                          )])
                ))),
    );
  }

}

class test extends StatefulWidget {
  @override
  _testState createState() => _testState();
}

class _testState extends State<test>{
  @override
  Widget build(BuildContext context){
    return  Scaffold(
      backgroundColor: Colors.red,
      body: Center(
        child: ElevatedButton(
        onPressed: () {
          Navigator.pop(context);
          },
          child: const Text('Go back!'),
      ),),
    );
  }
}